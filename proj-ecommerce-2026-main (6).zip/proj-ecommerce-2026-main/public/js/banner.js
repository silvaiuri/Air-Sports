
document.addEventListener("DOMContentLoaded", () => {
    const hero = document.querySelector(".hero");
    const heroPhoto = document.querySelector(".hero-photo");

    const reduzirMovimento = window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    ).matches;

    if (hero && heroPhoto) {
        const fotos = [
            "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?w=1800&auto=format&fit=crop&q=90",
            "https://images.unsplash.com/photo-1546519638-68e109498ffc?w=1800&auto=format&fit=crop&q=90",
            "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1800&auto=format&fit=crop&q=90"
        ];

        const indicadores = document.createElement("div");
        indicadores.className = "hero-indicators";

        let atual = 0;
        let trocando = false;
        let intervalo;

        fotos.forEach((foto, index) => {
            const imagem = new Image();
            imagem.src = foto;

            const botao = document.createElement("button");
            botao.className = "hero-indicator";
            botao.type = "button";
            botao.setAttribute(
                "aria-label",
                `Mostrar imagem ${index + 1}`
            );

            botao.addEventListener("click", () => {
                mudarImagem(index);
                reiniciarIntervalo();
            });

            indicadores.appendChild(botao);
        });

        hero.appendChild(indicadores);

        const botoes = indicadores.querySelectorAll(
            ".hero-indicator"
        );

        function atualizarIndicadores() {
            botoes.forEach((botao, index) => {
                botao.classList.toggle(
                    "active",
                    index === atual
                );
            });
        }

        function mudarImagem(proxima) {
            if (trocando || proxima === atual) return;

            trocando = true;
            heroPhoto.style.opacity = "0";

            setTimeout(() => {
                atual = proxima;

                heroPhoto.style.backgroundImage =
                    `url("${fotos[atual]}")`;

                atualizarIndicadores();

                heroPhoto.style.opacity = "1";
                trocando = false;
            }, reduzirMovimento ? 0 : 1000);
        }

        function reiniciarIntervalo() {
            clearInterval(intervalo);

            if (!reduzirMovimento) {
                intervalo = setInterval(() => {
                    mudarImagem(
                        (atual + 1) % fotos.length
                    );
                }, 5000);
            }
        }

        atualizarIndicadores();
        reiniciarIntervalo();
    }

    if (!reduzirMovimento && "IntersectionObserver" in window) {
        const estilo = document.createElement("style");

        estilo.textContent = `
            .air-reveal {
                opacity: 0;
                transform: translateY(30px);
                transition:
                    opacity .75s ease,
                    transform .75s ease;
            }

            .air-reveal.air-visible {
                opacity: 1;
                transform: translateY(0);
            }
        `;

        document.head.appendChild(estilo);

        const elementos = document.querySelectorAll(
            ".section-header, " +
            ".category-card, " +
            ".product-card, " +
            ".about-image, " +
            ".about-content, " +
            ".benefits-grid > div"
        );

        const observador = new IntersectionObserver(
            (entradas) => {
                entradas.forEach((entrada) => {
                    if (entrada.isIntersecting) {
                        entrada.target.classList.add(
                            "air-visible"
                        );

                        observador.unobserve(entrada.target);
                    }
                });
            },
            { threshold: 0.08 }
        );

        elementos.forEach((elemento) => {
            elemento.classList.add("air-reveal");
            observador.observe(elemento);
        });
    }

    const header = document.querySelector(".header");

    const botaoTopo = document.createElement("button");
    botaoTopo.type = "button";
    botaoTopo.className = "air-back-top";
    botaoTopo.textContent = "↑";
    botaoTopo.setAttribute(
        "aria-label",
        "Voltar ao topo"
    );

    document.body.appendChild(botaoTopo);

    const estiloTopo = document.createElement("style");

    estiloTopo.textContent = `
        .air-back-top {
            position: fixed;
            z-index: 120;
            bottom: 25px;
            right: 25px;
            width: 48px;
            height: 48px;
            border: 0;
            background: #ff6500;
            color: white;
            font-size: 25px;
            font-weight: 800;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transform: translateY(15px);
            transition: .3s;
            box-shadow: 0 8px 30px #0008;
        }

        .air-back-top.visible {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .air-back-top:hover {
            background: white;
            color: black;
        }
    `;

    document.head.appendChild(estiloTopo);

    function atualizarRolagem() {
        if (header) {
            header.classList.toggle(
                "scrolled",
                window.scrollY > 60
            );
        }

        botaoTopo.classList.toggle(
            "visible",
            window.scrollY > 450
        );
    }

    window.addEventListener(
        "scroll",
        atualizarRolagem,
        { passive: true }
    );

    atualizarRolagem();

    botaoTopo.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: reduzirMovimento ? "auto" : "smooth"
        });
    });
});
