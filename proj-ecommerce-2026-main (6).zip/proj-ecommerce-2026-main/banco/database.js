
const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./banco/ecommerce.db', (erro) => {
    if (erro) {
        console.error('Erro ao conectar ao banco:', erro.message);
    } else {
        console.log('Banco conectado.');
    }
});

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            descricao TEXT
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS marcas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            categoria TEXT,
            marca TEXT,
            valor REAL,
            estoque INTEGER DEFAULT 0,
            descricao TEXT,
            imagem TEXT,
            tamanhos TEXT,
            cores TEXT
        )
    `);

    db.all('PRAGMA table_info(produtos)', [], (erro, colunas) => {
        if (erro) {
            console.error('Erro ao verificar produtos:', erro.message);
            return;
        }

        const campos = [
            { nome: 'marca', tipo: 'TEXT' },
            { nome: 'tamanhos', tipo: 'TEXT' },
            { nome: 'cores', tipo: 'TEXT' }
        ];

        campos.forEach(campo => {
            const existe = colunas.some(
                coluna => coluna.name === campo.nome
            );

            if (!existe) {
                db.run(
                    `ALTER TABLE produtos ADD COLUMN ${campo.nome} ${campo.tipo}`,
                    erro => {
                        if (erro) {
                            console.error(
                                `Erro ao adicionar ${campo.nome}:`,
                                erro.message
                            );
                        } else {
                            console.log(
                                `Campo ${campo.nome} adicionado aos produtos.`
                            );
                        }
                    }
                );
            }
        });
    });
});

module.exports = db;
