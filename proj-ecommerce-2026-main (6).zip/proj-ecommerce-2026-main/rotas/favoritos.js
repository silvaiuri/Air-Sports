
const express = require('express');
const db = require('../banco/database');

const router = express.Router();

db.run(`
    CREATE TABLE IF NOT EXISTS favoritos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        produto_id INTEGER NOT NULL,
        criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(usuario_id, produto_id)
    )
`, erro => {
    if (erro) {
        console.error('Erro ao criar tabela de favoritos:', erro.message);
    } else {
        console.log('Sistema de favoritos preparado.');
    }
});

function exigirLogin(req, res, next) {
    if (!req.session.usuario) {
        if (req.path === '/ids' || req.method === 'POST') {
            return res.status(401).json({
                sucesso: false,
                login: true,
                mensagem: 'Entre na sua conta para salvar favoritos.'
            });
        }

        return res.redirect('/entrar');
    }

    next();
}

router.get('/ids', (req, res) => {
    if (!req.session.usuario) {
        return res.json({ ids: [] });
    }

    db.all(
        'SELECT produto_id FROM favoritos WHERE usuario_id = ?',
        [req.session.usuario.id],
        (erro, favoritos) => {
            if (erro) {
                return res.status(500).json({
                    mensagem: 'Erro ao carregar favoritos.'
                });
            }

            res.json({
                ids: favoritos.map(item => item.produto_id)
            });
        }
    );
});

router.get('/', exigirLogin, (req, res) => {
    db.all(
        `SELECT p.*
         FROM favoritos f
         INNER JOIN produtos p ON p.id = f.produto_id
         WHERE f.usuario_id = ?
         ORDER BY f.id DESC`,
        [req.session.usuario.id],
        (erro, produtos) => {
            if (erro) {
                return res.status(500).send(
                    'Erro ao carregar produtos favoritos.'
                );
            }

            res.render('favoritos', { produtos });
        }
    );
});

router.post('/:id', exigirLogin, (req, res) => {
    const produtoId = Number(req.params.id);
    const usuarioId = req.session.usuario.id;

    if (!Number.isSafeInteger(produtoId) || produtoId <= 0) {
        return res.status(400).json({
            sucesso: false,
            mensagem: 'Produto inválido.'
        });
    }

    db.get(
        'SELECT id FROM produtos WHERE id = ?',
        [produtoId],
        (erro, produto) => {
            if (erro) {
                return res.status(500).json({
                    sucesso: false,
                    mensagem: 'Erro ao consultar produto.'
                });
            }

            if (!produto) {
                return res.status(404).json({
                    sucesso: false,
                    mensagem: 'Produto não encontrado.'
                });
            }

            db.get(
                `SELECT id FROM favoritos
                 WHERE usuario_id = ? AND produto_id = ?`,
                [usuarioId, produtoId],
                (erro, favorito) => {
                    if (erro) {
                        return res.status(500).json({
                            sucesso: false,
                            mensagem: 'Erro ao consultar favorito.'
                        });
                    }

                    if (favorito) {
                        db.run(
                            `DELETE FROM favoritos
                             WHERE usuario_id = ? AND produto_id = ?`,
                            [usuarioId, produtoId],
                            erro => {
                                if (erro) {
                                    return res.status(500).json({
                                        sucesso: false,
                                        mensagem: 'Erro ao remover favorito.'
                                    });
                                }

                                res.json({
                                    sucesso: true,
                                    favorito: false,
                                    mensagem: 'Produto removido dos favoritos.'
                                });
                            }
                        );
                    } else {
                        db.run(
                            `INSERT OR IGNORE INTO favoritos
                             (usuario_id, produto_id)
                             VALUES (?, ?)`,
                            [usuarioId, produtoId],
                            erro => {
                                if (erro) {
                                    return res.status(500).json({
                                        sucesso: false,
                                        mensagem: 'Erro ao adicionar favorito.'
                                    });
                                }

                                res.json({
                                    sucesso: true,
                                    favorito: true,
                                    mensagem: 'Produto adicionado aos favoritos!'
                                });
                            }
                        );
                    }
                }
            );
        }
    );
});

module.exports = router;
