
const express = require('express');
const router = express.Router();
const db = require('../banco/database');
const upload = require('../util/imagens');

router.get('/', (req, res) => res.redirect('/admin/index'));

router.get('/index', (req, res) => {
    res.render('admin/index-admin');
});

router.get('/marcas', (req, res) => {
    db.all('SELECT * FROM marcas ORDER BY nome', [], (erro, marcas) => {
        if (erro) return res.status(500).send('Erro ao consultar marcas.');

        const id = Number(req.query.editar || 0);

        if (!id) {
            return res.render('admin/marcas', {
                marcas,
                marcaEditar: null,
                aviso: req.query.aviso || ''
            });
        }

        db.get('SELECT * FROM marcas WHERE id = ?', [id], (erro, marcaEditar) => {
            if (erro) return res.status(500).send('Erro ao consultar marca.');

            res.render('admin/marcas', {
                marcas,
                marcaEditar: marcaEditar || null,
                aviso: req.query.aviso || ''
            });
        });
    });
});

router.post('/marcas/cadastrar', (req, res) => {
    const nome = String(req.body.nome || '').trim();

    if (!nome) return res.redirect('/admin/marcas?aviso=invalida');

    db.get(
        'SELECT id FROM marcas WHERE LOWER(TRIM(nome)) = LOWER(?)',
        [nome],
        (erro, existente) => {
            if (erro) return res.status(500).send('Erro ao consultar marcas.');
            if (existente) return res.redirect('/admin/marcas?aviso=duplicada');

            db.run('INSERT INTO marcas (nome) VALUES (?)', [nome], erro => {
                if (erro) return res.status(500).send('Erro ao cadastrar marca.');
                res.redirect('/admin/marcas?aviso=cadastrada');
            });
        }
    );
});

router.post('/marcas/editar/:id', (req, res) => {
    const nome = String(req.body.nome || '').trim();
    const id = req.params.id;

    if (!nome) return res.redirect('/admin/marcas?aviso=invalida');

    db.get('SELECT * FROM marcas WHERE id = ?', [id], (erro, atual) => {
        if (erro) return res.status(500).send('Erro ao consultar marca.');
        if (!atual) return res.status(404).send('Marca não encontrada.');

        db.get(
            'SELECT id FROM marcas WHERE LOWER(TRIM(nome)) = LOWER(?) AND id != ?',
            [nome, id],
            (erro, existente) => {
                if (erro) return res.status(500).send('Erro ao consultar marcas.');
                if (existente) return res.redirect('/admin/marcas?aviso=duplicada');

                db.get(
                    'SELECT COUNT(*) AS total FROM produtos WHERE LOWER(TRIM(marca)) = LOWER(?)',
                    [atual.nome],
                    (erro, resultado) => {
                        if (erro) return res.status(500).send('Erro ao consultar produtos.');

                        if (resultado.total > 0 && nome !== atual.nome) {
                            return res.redirect('/admin/marcas?aviso=emuso');
                        }

                        db.run(
                            'UPDATE marcas SET nome = ? WHERE id = ?',
                            [nome, id],
                            erro => {
                                if (erro) return res.status(500).send('Erro ao atualizar marca.');
                                res.redirect('/admin/marcas?aviso=editada');
                            }
                        );
                    }
                );
            }
        );
    });
});

router.post('/marcas/excluir/:id', (req, res) => {
    db.get('SELECT * FROM marcas WHERE id = ?', [req.params.id], (erro, marca) => {
        if (erro) return res.status(500).send('Erro ao consultar marca.');
        if (!marca) return res.status(404).send('Marca não encontrada.');

        db.get(
            'SELECT COUNT(*) AS total FROM produtos WHERE LOWER(TRIM(marca)) = LOWER(?)',
            [marca.nome],
            (erro, resultado) => {
                if (erro) return res.status(500).send('Erro ao consultar produtos.');
                if (resultado.total > 0) return res.redirect('/admin/marcas?aviso=emuso');

                db.run('DELETE FROM marcas WHERE id = ?', [marca.id], erro => {
                    if (erro) return res.status(500).send('Erro ao excluir marca.');
                    res.redirect('/admin/marcas?aviso=excluida');
                });
            }
        );
    });
});

router.get('/categorias', (req, res) => {
    db.all('SELECT * FROM categorias ORDER BY nome, id', [], (erro, categorias) => {
        if (erro) return res.status(500).send('Erro ao carregar categorias.');

        res.render('admin/categorias/lista', {
            categorias,
            aviso: req.query.aviso || ''
        });
    });
});

router.get('/categorias/form-cadastrar', (req, res) => {
    res.render('admin/categorias/cadastro', {
        categoria: null,
        erro: null
    });
});

router.post('/categorias/cadastrar', (req, res) => {
    const nome = String(req.body.nome || '').trim();
    const descricao = String(req.body.descricao || '').trim();

    if (!nome) {
        return res.status(400).render('admin/categorias/cadastro', {
            categoria: { nome, descricao },
            erro: 'Informe o nome da categoria.'
        });
    }

    db.get(
        'SELECT id FROM categorias WHERE LOWER(TRIM(nome)) = LOWER(?)',
        [nome],
        (erro, existente) => {
            if (erro) return res.status(500).send('Erro ao consultar categorias.');

            if (existente) {
                return res.status(400).render('admin/categorias/cadastro', {
                    categoria: { nome, descricao },
                    erro: 'Já existe uma categoria com esse nome.'
                });
            }

            db.run(
                'INSERT INTO categorias (nome, descricao) VALUES (?, ?)',
                [nome, descricao],
                erro => {
                    if (erro) return res.status(500).send('Erro ao cadastrar categoria.');
                    res.redirect('/admin/categorias?aviso=cadastrada');
                }
            );
        }
    );
});

router.get('/categorias/editar/:id', (req, res) => {
    db.get('SELECT * FROM categorias WHERE id = ?', [req.params.id], (erro, categoria) => {
        if (erro) return res.status(500).send('Erro ao consultar categoria.');
        if (!categoria) return res.status(404).send('Categoria não encontrada.');

        res.render('admin/categorias/cadastro', {
            categoria,
            erro: null
        });
    });
});

router.post('/categorias/editar/:id', (req, res) => {
    const id = req.params.id;
    const nome = String(req.body.nome || '').trim();
    const descricao = String(req.body.descricao || '').trim();

    if (!nome) return res.status(400).send('Informe o nome da categoria.');

    db.get('SELECT * FROM categorias WHERE id = ?', [id], (erro, atual) => {
        if (erro) return res.status(500).send('Erro ao consultar categoria.');
        if (!atual) return res.status(404).send('Categoria não encontrada.');

        db.get(
            'SELECT id FROM categorias WHERE LOWER(TRIM(nome)) = LOWER(?) AND id != ?',
            [nome, id],
            (erro, existente) => {
                if (erro) return res.status(500).send('Erro ao consultar categorias.');

                if (existente) {
                    return res.status(400).render('admin/categorias/cadastro', {
                        categoria: { id, nome, descricao },
                        erro: 'Já existe uma categoria com esse nome.'
                    });
                }

                db.get(
                    'SELECT COUNT(*) AS total FROM produtos WHERE categoria = ?',
                    [atual.nome],
                    (erro, resultado) => {
                        if (erro) return res.status(500).send('Erro ao consultar produtos.');

                        if (resultado.total > 0 && nome !== atual.nome) {
                            return res.status(400).render('admin/categorias/cadastro', {
                                categoria: { id, nome, descricao },
                                erro: 'Essa categoria possui produtos. Altere esses produtos antes de renomeá-la.'
                            });
                        }

                        db.run(
                            'UPDATE categorias SET nome = ?, descricao = ? WHERE id = ?',
                            [nome, descricao, id],
                            erro => {
                                if (erro) return res.status(500).send('Erro ao atualizar categoria.');
                                res.redirect('/admin/categorias?aviso=editada');
                            }
                        );
                    }
                );
            }
        );
    });
});

router.post('/categorias/excluir/:id', (req, res) => {
    db.get('SELECT * FROM categorias WHERE id = ?', [req.params.id], (erro, categoria) => {
        if (erro) return res.status(500).send('Erro ao consultar categoria.');
        if (!categoria) return res.status(404).send('Categoria não encontrada.');

        db.get(
            'SELECT COUNT(*) AS total FROM produtos WHERE categoria = ?',
            [categoria.nome],
            (erro, resultado) => {
                if (erro) return res.status(500).send('Erro ao consultar produtos.');
                if (resultado.total > 0) return res.redirect('/admin/categorias?aviso=emuso');

                db.run('DELETE FROM categorias WHERE id = ?', [categoria.id], erro => {
                    if (erro) return res.status(500).send('Erro ao excluir categoria.');
                    res.redirect('/admin/categorias?aviso=excluida');
                });
            }
        );
    });
});

router.get('/produtos', (req, res) => {
    db.all('SELECT * FROM produtos ORDER BY id DESC', [], (erro, produtos) => {
        if (erro) return res.status(500).send('Erro ao consultar produtos.');
        res.render('admin/produtos/lista', { produtos });
    });
});

function carregarOpcoes(callback) {
    db.all('SELECT * FROM categorias ORDER BY nome', [], (erro, categorias) => {
        if (erro) return callback(erro);

        db.all('SELECT * FROM marcas ORDER BY nome', [], (erro, marcas) => {
            if (erro) return callback(erro);
            callback(null, categorias, marcas);
        });
    });
}

function dadosProduto(body) {
    return {
        nome: String(body.nome || '').trim(),
        categoria: String(body.categoria || '').trim(),
        marca: String(body.marca || '').trim(),
        valor: Number(body.valor),
        estoque: Number(body.estoque),
        descricao: String(body.descricao || '').trim(),
        tamanhos: String(body.tamanhos || '').split(',')
            .map(item => item.trim())
            .filter(Boolean)
            .join(', '),
        cores: String(body.cores || '').split(',')
            .map(item => item.trim())
            .filter(Boolean)
            .join(', ')
    };
}

function dadosValidos(body, dados) {
    return (
        dados.nome &&
        dados.categoria &&
        dados.marca &&
        body.valor !== undefined &&
        String(body.valor).trim() !== '' &&
        Number.isFinite(dados.valor) &&
        dados.valor >= 0 &&
        body.estoque !== undefined &&
        String(body.estoque).trim() !== '' &&
        Number.isInteger(dados.estoque) &&
        dados.estoque >= 0
    );
}

router.get('/produtos/form-cadastrar', (req, res) => {
    carregarOpcoes((erro, categorias, marcas) => {
        if (erro) return res.status(500).send('Erro ao carregar opções.');

        res.render('admin/produtos/cadastro', {
            categorias,
            marcas,
            produto: null
        });
    });
});

router.post('/produtos/cadastrar', upload.single('imagem'), (req, res) => {
    const dados = dadosProduto(req.body);

    if (!dadosValidos(req.body, dados) || !req.file) {
        return res.status(400).send('Confira os dados e a imagem do produto.');
    }

    db.run(
        `INSERT INTO produtos
        (nome, categoria, marca, valor, estoque, descricao, imagem, tamanhos, cores)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            dados.nome,
            dados.categoria,
            dados.marca,
            dados.valor,
            dados.estoque,
            dados.descricao,
            req.file.filename,
            dados.tamanhos,
            dados.cores
        ],
        erro => {
            if (erro) return res.status(500).send('Erro ao cadastrar produto.');
            res.redirect('/admin/produtos');
        }
    );
});

router.get('/produtos/editar/:id', (req, res) => {
    db.get('SELECT * FROM produtos WHERE id = ?', [req.params.id], (erro, produto) => {
        if (erro) return res.status(500).send('Erro ao consultar produto.');
        if (!produto) return res.status(404).send('Produto não encontrado.');

        carregarOpcoes((erro, categorias, marcas) => {
            if (erro) return res.status(500).send('Erro ao carregar opções.');

            res.render('admin/produtos/cadastro', {
                categorias,
                marcas,
                produto
            });
        });
    });
});

router.post('/produtos/editar/:id', upload.single('imagem'), (req, res) => {
    const dados = dadosProduto(req.body);

    if (!dadosValidos(req.body, dados)) {
        return res.status(400).send('Confira os dados do produto.');
    }

    db.get('SELECT * FROM produtos WHERE id = ?', [req.params.id], (erro, produto) => {
        if (erro) return res.status(500).send('Erro ao consultar produto.');
        if (!produto) return res.status(404).send('Produto não encontrado.');

        const imagem = req.file ? req.file.filename : produto.imagem;

        db.run(
            `UPDATE produtos SET
                nome = ?,
                categoria = ?,
                marca = ?,
                valor = ?,
                estoque = ?,
                descricao = ?,
                imagem = ?,
                tamanhos = ?,
                cores = ?
             WHERE id = ?`,
            [
                dados.nome,
                dados.categoria,
                dados.marca,
                dados.valor,
                dados.estoque,
                dados.descricao,
                imagem,
                dados.tamanhos,
                dados.cores,
                req.params.id
            ],
            erro => {
                if (erro) return res.status(500).send('Erro ao editar produto.');
                res.redirect('/admin/produtos');
            }
        );
    });
});

router.post('/produtos/excluir/:id', (req, res) => {
    db.run('DELETE FROM produtos WHERE id = ?', [req.params.id], erro => {
        if (erro) return res.status(500).send('Erro ao excluir produto.');
        res.redirect('/admin/produtos');
    });
});

module.exports = router;
