
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('./banco/database');
const appAdmin = require('./rotas/admin');

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 8
    }
}));

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL,
            tipo TEXT NOT NULL DEFAULT 'cliente'
            CHECK(tipo IN ('cliente', 'admin'))
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            nome_cliente TEXT NOT NULL,
            email TEXT NOT NULL,
            cep TEXT NOT NULL,
            rua TEXT NOT NULL,
            numero TEXT NOT NULL,
            complemento TEXT,
            bairro TEXT NOT NULL,
            cidade TEXT NOT NULL,
            estado TEXT NOT NULL,
            total REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'Recebido',
            criado_em TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS pedido_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL,
            produto_id INTEGER,
            nome_produto TEXT NOT NULL,
            marca TEXT,
            tamanho TEXT,
            cor TEXT,
            quantidade INTEGER NOT NULL,
            valor_unitario REAL NOT NULL,
            subtotal REAL NOT NULL
        )
    `);
});

function executar(sql, parametros = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, parametros, function (erro) {
            if (erro) return reject(erro);
            resolve({
                id: this.lastID,
                alteracoes: this.changes
            });
        });
    });
}

function consultar(sql, parametros = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, parametros, (erro, resultado) => {
            if (erro) return reject(erro);
            resolve(resultado);
        });
    });
}

function consultarTodos(sql, parametros = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, parametros, (erro, resultados) => {
            if (erro) return reject(erro);
            resolve(resultados);
        });
    });
}

function opcoes(texto) {
    return [...new Set(
        String(texto || '')
            .split(',')
            .map(valor => valor.trim())
            .filter(Boolean)
    )];
}

function idValido(valor) {
    const id = Number(valor);
    return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function estoqueDisponivel(produto) {
    return Math.max(0, Math.floor(Number(produto.estoque) || 0));
}

function carrinhoDaSessao(req) {
    if (!Array.isArray(req.session.carrinho)) {
        req.session.carrinho = [];
    }

    return req.session.carrinho;
}

function mesmaVariacao(item, id, tamanho, cor) {
    return item.id === id &&
        String(item.tamanho || '') === tamanho &&
        String(item.cor || '') === cor;
}

function quantidadeTotal(carrinho, id) {
    return carrinho
        .filter(item => item.id === id)
        .reduce((soma, item) => soma + Number(item.quantidade || 0), 0);
}

function salvarERedirecionar(req, res, destino = '/carrinho') {
    req.session.save(erro => {
        if (erro) return res.status(500).send('Erro ao salvar sessão.');
        res.redirect(destino);
    });
}

function exigirLogin(req, res, next) {
    if (!req.session.usuario) return res.redirect('/entrar');
    next();
}

function exigirAdmin(req, res, next) {
    if (!req.session.usuario) return res.redirect('/entrar');

    if (req.session.usuario.tipo !== 'admin') {
        return res.status(403).send('Acesso exclusivo para administradores.');
    }

    next();
}

app.use((req, res, next) => {
    res.locals.usuario = req.session.usuario || null;

    res.locals.qtdCarrinho = (req.session.carrinho || [])
        .reduce((soma, item) => soma + Number(item.quantidade || 0), 0);

    next();
});

let filaOperacoes = Promise.resolve();

function enfileirarOperacao(operacao) {
    const tarefa = filaOperacoes.then(operacao);
    filaOperacoes = tarefa.catch(() => {});
    return tarefa;
}

async function obterItensCarrinho(req) {
    const carrinho = carrinhoDaSessao(req);

    if (carrinho.length === 0) {
        return { itens: [], total: 0 };
    }

    const ids = [...new Set(carrinho.map(item => item.id))];
    const marcadores = ids.map(() => '?').join(',');

    const produtos = await consultarTodos(
        `SELECT * FROM produtos WHERE id IN (${marcadores})`,
        ids
    );

    const itens = [];
    const utilizados = {};
    let total = 0;

    for (const item of carrinho) {
        const produto = produtos.find(p => p.id === item.id);
        if (!produto) continue;

        const tamanhos = opcoes(produto.tamanhos);
        const cores = opcoes(produto.cores);
        const tamanho = String(item.tamanho || '');
        const cor = String(item.cor || '');

        if (tamanhos.length && !tamanhos.includes(tamanho)) continue;
        if (cores.length && !cores.includes(cor)) continue;

        const usados = utilizados[produto.id] || 0;
        const restantes = Math.max(0, estoqueDisponivel(produto) - usados);
        const solicitada = Math.max(0, Math.floor(Number(item.quantidade) || 0));
        const quantidade = Math.min(solicitada, restantes);

        if (!quantidade) continue;

        utilizados[produto.id] = usados + quantidade;

        const subtotal = Number(produto.valor || 0) * quantidade;

        const existente = itens.find(outro =>
            mesmaVariacao(outro, produto.id, tamanho, cor)
        );

        if (existente) {
            existente.quantidade += quantidade;
            existente.subtotal += subtotal;
        } else {
            itens.push({
                id: produto.id,
                produto,
                tamanho,
                cor,
                quantidade,
                subtotal
            });
        }

        total += subtotal;
    }

    req.session.carrinho = itens.map(item => ({
        id: item.id,
        tamanho: item.tamanho,
        cor: item.cor,
        quantidade: item.quantidade
    }));

    return { itens, total };
}

app.get('/', async (req, res) => {
    try {
        const produtos = await consultarTodos(
            'SELECT * FROM produtos ORDER BY id DESC LIMIT 3'
        );

        const categorias = await consultarTodos(`
            SELECT MIN(id) AS id, nome
            FROM categorias
            GROUP BY LOWER(TRIM(nome))
            ORDER BY nome
            LIMIT 4
        `);

        res.render('index', { produtos, categorias });
    } catch (erro) {
        res.status(500).send('Erro ao carregar a loja.');
    }
});

app.get('/entrar', (req, res) => {
    if (req.session.usuario) return res.redirect('/');
    res.render('entrar', { erro: null });
});

app.post('/entrar', async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    try {
        const usuario = await consultar(
            'SELECT * FROM usuarios WHERE email = ?',
            [email]
        );

        let senhaCorreta = false;

        if (usuario) {
            try {
                senhaCorreta = await bcrypt.compare(senha, usuario.senha);
            } catch (erro) {
                senhaCorreta = false;
            }
        }

        if (!usuario || !senhaCorreta) {
            return res.status(401).render('entrar', {
                erro: 'E-mail ou senha incorretos.'
            });
        }

        const carrinhoAtual = carrinhoDaSessao(req);

        req.session.regenerate(erro => {
            if (erro) return res.status(500).send('Erro ao iniciar sessão.');

            req.session.usuario = {
                id: usuario.id,
                nome: usuario.nome,
                tipo: usuario.tipo
            };

            req.session.carrinho = carrinhoAtual;
            salvarERedirecionar(req, res, '/');
        });
    } catch (erro) {
        res.status(500).send('Erro ao realizar login.');
    }
});

app.get('/cadastro', (req, res) => {
    if (req.session.usuario) return res.redirect('/');
    res.render('cadastro', { erro: null });
});

app.post('/cadastro', async (req, res) => {
    const nome = String(req.body.nome || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    if (!nome || !email.includes('@') || senha.length < 8) {
        return res.status(400).render('cadastro', {
            erro: 'Preencha os dados e use uma senha de pelo menos 8 caracteres.'
        });
    }

    try {
        const senhaProtegida = await bcrypt.hash(senha, 12);

        await executar(
            'INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)',
            [nome, email, senhaProtegida, 'cliente']
        );

        res.redirect('/entrar');
    } catch (erro) {
        res.status(400).render('cadastro', {
            erro: 'Não foi possível cadastrar. Verifique se o e-mail já existe.'
        });
    }
});

app.post('/sair', (req, res) => {
    req.session.destroy(() => {
        res.clearCookie('connect.sid');
        res.redirect('/');
    });
});

app.get('/minha-conta', exigirLogin, async (req, res) => {
    try {
        const conta = await consultar(
            'SELECT id, nome, email, tipo FROM usuarios WHERE id = ?',
            [req.session.usuario.id]
        );

        if (!conta) {
            return req.session.destroy(() => {
                res.clearCookie('connect.sid');
                res.redirect('/entrar');
            });
        }

        res.render('minha-conta', {
            conta,
            aviso: String(req.query.aviso || '')
        });
    } catch (erro) {
        res.status(500).send('Erro ao carregar conta.');
    }
});

app.post('/minha-conta/dados', exigirLogin, async (req, res) => {
    const nome = String(req.body.nome || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();

    if (
        nome.length < 2 ||
        nome.length > 100 ||
        email.length > 254 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
    ) {
        return res.redirect('/minha-conta?aviso=dadosinvalidos');
    }

    try {
        const resultado = await executar(
            'UPDATE usuarios SET nome = ?, email = ? WHERE id = ?',
            [nome, email, req.session.usuario.id]
        );

        if (!resultado.alteracoes) {
            return res.status(404).send('Conta não encontrada.');
        }

        req.session.usuario.nome = nome;
        salvarERedirecionar(req, res, '/minha-conta?aviso=dadossalvos');
    } catch (erro) {
        if (erro.code === 'SQLITE_CONSTRAINT') {
            return res.redirect('/minha-conta?aviso=emailusado');
        }

        res.status(500).send('Erro ao atualizar dados.');
    }
});

app.post('/minha-conta/senha', exigirLogin, async (req, res) => {
    const senhaAtual = String(req.body.senhaAtual || '');
    const novaSenha = String(req.body.novaSenha || '');
    const confirmarSenha = String(req.body.confirmarSenha || '');

    if (novaSenha.length < 8 || novaSenha.length > 72) {
        return res.redirect('/minha-conta?aviso=senhainvalida');
    }

    if (novaSenha !== confirmarSenha) {
        return res.redirect('/minha-conta?aviso=senhasdiferentes');
    }

    try {
        const conta = await consultar(
            'SELECT senha FROM usuarios WHERE id = ?',
            [req.session.usuario.id]
        );

        if (!conta) return res.status(404).send('Conta não encontrada.');

        if (!(await bcrypt.compare(senhaAtual, conta.senha))) {
            return res.redirect('/minha-conta?aviso=senhaerrada');
        }

        if (await bcrypt.compare(novaSenha, conta.senha)) {
            return res.redirect('/minha-conta?aviso=senharepetida');
        }

        const protegida = await bcrypt.hash(novaSenha, 12);

        await executar(
            'UPDATE usuarios SET senha = ? WHERE id = ?',
            [protegida, req.session.usuario.id]
        );

        res.redirect('/minha-conta?aviso=senhasalva');
    } catch (erro) {
        res.status(500).send('Erro ao alterar senha.');
    }
});

app.get('/produtos', async (req, res) => {
    const categoria = String(req.query.categoria || '');

    try {
        const produtos = await consultarTodos(
            categoria
                ? 'SELECT * FROM produtos WHERE categoria = ? ORDER BY id DESC'
                : 'SELECT * FROM produtos ORDER BY id DESC',
            categoria ? [categoria] : []
        );

        const categorias = await consultarTodos(`
            SELECT MIN(id) AS id, nome
            FROM categorias
            GROUP BY LOWER(TRIM(nome))
            ORDER BY nome
        `);

        res.render('produtos', {
            produtos,
            categorias,
            categoria
        });
    } catch (erro) {
        res.status(500).send('Erro ao carregar produtos.');
    }
});

app.get('/produtos/:id', async (req, res) => {
    const id = idValido(req.params.id);
    if (!id) return res.status(404).send('Produto não encontrado.');

    try {
        const produto = await consultar(
            'SELECT * FROM produtos WHERE id = ?',
            [id]
        );

        if (!produto) return res.status(404).send('Produto não encontrado.');

        const erros = {
            tamanho: 'Selecione um tamanho disponível.',
            cor: 'Selecione uma cor disponível.',
            estoque: 'Não há estoque disponível para adicionar mais unidades.'
        };

        res.render('produto', {
            produto,
            tamanhos: opcoes(produto.tamanhos),
            cores: opcoes(produto.cores),
            erroCarrinho: erros[req.query.erro] || null
        });
    } catch (erro) {
        res.status(500).send('Erro ao carregar produto.');
    }
});

app.get('/carrinho', async (req, res) => {
    try {
        const { itens, total } = await obterItensCarrinho(req);

        req.session.save(erro => {
            if (erro) return res.status(500).send('Erro ao salvar carrinho.');
            res.render('carrinho', { itens, total });
        });
    } catch (erro) {
        res.status(500).send('Erro ao carregar carrinho.');
    }
});

app.post('/carrinho/adicionar/:id', async (req, res) => {
    const id = idValido(req.params.id);
    if (!id) return res.status(404).send('Produto não encontrado.');

    try {
        const produto = await consultar(
            'SELECT * FROM produtos WHERE id = ?',
            [id]
        );

        if (!produto) return res.status(404).send('Produto não encontrado.');

        const tamanhos = opcoes(produto.tamanhos);
        const cores = opcoes(produto.cores);
        const tamanho = String(req.body.tamanho || '').trim();
        const cor = String(req.body.cor || '').trim();

        if (tamanhos.length && !tamanhos.includes(tamanho)) {
            return res.redirect(`/produtos/${id}?erro=tamanho`);
        }

        if (cores.length && !cores.includes(cor)) {
            return res.redirect(`/produtos/${id}?erro=cor`);
        }

        const tamanhoFinal = tamanhos.length ? tamanho : '';
        const corFinal = cores.length ? cor : '';
        const carrinho = carrinhoDaSessao(req);

        if (quantidadeTotal(carrinho, id) >= estoqueDisponivel(produto)) {
            return res.redirect(`/produtos/${id}?erro=estoque`);
        }

        const item = carrinho.find(item =>
            mesmaVariacao(item, id, tamanhoFinal, corFinal)
        );

        if (item) {
            item.quantidade += 1;
        } else {
            carrinho.push({
                id,
                tamanho: tamanhoFinal,
                cor: corFinal,
                quantidade: 1
            });
        }

        salvarERedirecionar(req, res);
    } catch (erro) {
        res.status(500).send('Erro ao adicionar produto.');
    }
});

app.post('/carrinho/aumentar/:id', async (req, res) => {
    const id = idValido(req.params.id);
    const tamanho = String(req.body.tamanho || '');
    const cor = String(req.body.cor || '');
    const carrinho = carrinhoDaSessao(req);

    const item = carrinho.find(item =>
        mesmaVariacao(item, id, tamanho, cor)
    );

    if (!item) return res.redirect('/carrinho');

    try {
        const produto = await consultar(
            'SELECT estoque FROM produtos WHERE id = ?',
            [id]
        );

        if (
            produto &&
            quantidadeTotal(carrinho, id) < estoqueDisponivel(produto)
        ) {
            item.quantidade += 1;
        }

        salvarERedirecionar(req, res);
    } catch (erro) {
        res.status(500).send('Erro ao atualizar quantidade.');
    }
});

app.post('/carrinho/diminuir/:id', (req, res) => {
    const id = idValido(req.params.id);
    const tamanho = String(req.body.tamanho || '');
    const cor = String(req.body.cor || '');

    req.session.carrinho = carrinhoDaSessao(req).flatMap(item => {
        if (!mesmaVariacao(item, id, tamanho, cor)) return [item];
        if (item.quantidade <= 1) return [];

        return [{ ...item, quantidade: item.quantidade - 1 }];
    });

    salvarERedirecionar(req, res);
});

app.post('/carrinho/remover/:id', (req, res) => {
    const id = idValido(req.params.id);
    const tamanho = String(req.body.tamanho || '');
    const cor = String(req.body.cor || '');

    req.session.carrinho = carrinhoDaSessao(req).filter(item =>
        !mesmaVariacao(item, id, tamanho, cor)
    );

    salvarERedirecionar(req, res);
});

app.get('/checkout', exigirLogin, async (req, res) => {
    try {
        const { itens, total } = await obterItensCarrinho(req);
        if (!itens.length) return res.redirect('/carrinho');

        const conta = await consultar(
            'SELECT nome, email FROM usuarios WHERE id = ?',
            [req.session.usuario.id]
        );

        if (!conta) return res.status(404).send('Conta não encontrada.');

        req.session.save(erro => {
            if (erro) return res.status(500).send('Erro ao preparar checkout.');

            res.render('checkout', {
                itens,
                total,
                conta,
                erro: null,
                dados: {}
            });
        });
    } catch (erro) {
        res.status(500).send('Erro ao preparar checkout.');
    }
});

app.post('/checkout', exigirLogin, async (req, res) => {
    const dados = {
        cep: String(req.body.cep || '').replace(/\D/g, ''),
        rua: String(req.body.rua || '').trim(),
        numero: String(req.body.numero || '').trim(),
        complemento: String(req.body.complemento || '').trim(),
        bairro: String(req.body.bairro || '').trim(),
        cidade: String(req.body.cidade || '').trim(),
        estado: String(req.body.estado || '').trim().toUpperCase()
    };

    const valido =
        dados.cep.length === 8 &&
        dados.rua.length >= 3 &&
        dados.numero.length > 0 &&
        dados.bairro.length >= 2 &&
        dados.cidade.length >= 2 &&
        /^[A-Z]{2}$/.test(dados.estado) &&
        [
            dados.rua,
            dados.numero,
            dados.complemento,
            dados.bairro,
            dados.cidade
        ].every(texto => texto.length <= 150);

    if (!valido) {
        try {
            const { itens, total } = await obterItensCarrinho(req);

            const conta = await consultar(
                'SELECT nome, email FROM usuarios WHERE id = ?',
                [req.session.usuario.id]
            );

            return res.status(400).render('checkout', {
                itens,
                total,
                conta,
                dados,
                erro: 'Preencha corretamente o endereço e o CEP de 8 dígitos.'
            });
        } catch (erro) {
            return res.status(500).send('Erro ao validar endereço.');
        }
    }

    try {
        const numeroPedido = await enfileirarOperacao(async () => {
            await executar('BEGIN IMMEDIATE TRANSACTION');

            try {
                const conta = await consultar(
                    'SELECT nome, email FROM usuarios WHERE id = ?',
                    [req.session.usuario.id]
                );

                if (!conta) throw new Error('Conta não encontrada.');

                const carrinho = carrinhoDaSessao(req);
                if (!carrinho.length) throw new Error('O carrinho está vazio.');

                const itensPedido = [];
                const totaisPorProduto = new Map();
                let totalCentavos = 0;

                for (const item of carrinho) {
                    const id = idValido(item.id);
                    const quantidade = Number(item.quantidade);

                    if (
                        !id ||
                        !Number.isSafeInteger(quantidade) ||
                        quantidade <= 0
                    ) {
                        throw new Error('Há itens inválidos no carrinho.');
                    }

                    const produto = await consultar(
                        'SELECT * FROM produtos WHERE id = ?',
                        [id]
                    );

                    if (!produto) {
                        throw new Error('Um produto não está mais disponível.');
                    }

                    const tamanho = String(item.tamanho || '');
                    const cor = String(item.cor || '');
                    const tamanhos = opcoes(produto.tamanhos);
                    const cores = opcoes(produto.cores);

                    if (
                        (tamanhos.length && !tamanhos.includes(tamanho)) ||
                        (cores.length && !cores.includes(cor))
                    ) {
                        throw new Error('Uma variação não está mais disponível.');
                    }

                    const preco = Number(produto.valor);

                    if (!Number.isFinite(preco) || preco < 0) {
                        throw new Error('Preço inválido.');
                    }

                    totaisPorProduto.set(
                        id,
                        (totaisPorProduto.get(id) || 0) + quantidade
                    );

                    const subtotalCentavos =
                        Math.round(preco * 100) * quantidade;

                    itensPedido.push({
                        produto,
                        tamanho,
                        cor,
                        quantidade,
                        preco,
                        subtotal: subtotalCentavos / 100
                    });

                    totalCentavos += subtotalCentavos;
                }

                for (const [id, quantidade] of totaisPorProduto) {
                    const atualizacao = await executar(
                        `UPDATE produtos
                         SET estoque = estoque - ?
                         WHERE id = ? AND estoque >= ?`,
                        [quantidade, id, quantidade]
                    );

                    if (atualizacao.alteracoes !== 1) {
                        throw new Error('Estoque insuficiente.');
                    }
                }

                const pedido = await executar(
                    `INSERT INTO pedidos
                    (usuario_id, nome_cliente, email, cep, rua, numero,
                     complemento, bairro, cidade, estado, total, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        req.session.usuario.id,
                        conta.nome,
                        conta.email,
                        dados.cep,
                        dados.rua,
                        dados.numero,
                        dados.complemento,
                        dados.bairro,
                        dados.cidade,
                        dados.estado,
                        totalCentavos / 100,
                        'Recebido'
                    ]
                );

                for (const item of itensPedido) {
                    await executar(
                        `INSERT INTO pedido_itens
                        (pedido_id, produto_id, nome_produto, marca,
                         tamanho, cor, quantidade, valor_unitario, subtotal)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [
                            pedido.id,
                            item.produto.id,
                            item.produto.nome,
                            item.produto.marca || '',
                            item.tamanho,
                            item.cor,
                            item.quantidade,
                            item.preco,
                            item.subtotal
                        ]
                    );
                }

                await executar('COMMIT');
                return pedido.id;
            } catch (erro) {
                await executar('ROLLBACK');
                throw erro;
            }
        });

        req.session.carrinho = [];

        salvarERedirecionar(
            req,
            res,
            `/meus-pedidos?sucesso=${numeroPedido}`
        );
    } catch (erro) {
        res.status(400).send(
            'Não foi possível confirmar o pedido: ' + erro.message
        );
    }
});

app.get('/meus-pedidos', exigirLogin, async (req, res) => {
    try {
        const pedidos = await consultarTodos(
            `SELECT * FROM pedidos
             WHERE usuario_id = ?
             ORDER BY id DESC`,
            [req.session.usuario.id]
        );

        for (const pedido of pedidos) {
            pedido.itens = await consultarTodos(
                'SELECT * FROM pedido_itens WHERE pedido_id = ?',
                [pedido.id]
            );
        }

        res.render('meus-pedidos', {
            pedidos,
            sucesso: Number(req.query.sucesso || 0)
        });
    } catch (erro) {
        res.status(500).send('Erro ao consultar pedidos.');
    }
});

app.get('/admin', exigirAdmin, (req, res) => {
    res.redirect('/admin/index');
});

app.get('/admin/index', exigirAdmin, async (req, res) => {
    try {
        const [
            produtos,
            categorias,
            marcas,
            clientes,
            pedidos,
            estoques
        ] = await Promise.all([
            consultar('SELECT COUNT(*) AS total FROM produtos'),
            consultar('SELECT COUNT(*) AS total FROM categorias'),
            consultar('SELECT COUNT(*) AS total FROM marcas'),
            consultar(
                `SELECT COUNT(*) AS total FROM usuarios
                 WHERE tipo = 'cliente'`
            ),
            consultar(`
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN status = 'Recebido' THEN 1 ELSE 0 END) AS recebidos,
                    SUM(CASE WHEN status = 'Em preparação' THEN 1 ELSE 0 END) AS preparacao,
                    SUM(CASE WHEN status = 'Enviado' THEN 1 ELSE 0 END) AS enviados,
                    SUM(CASE WHEN status = 'Entregue' THEN 1 ELSE 0 END) AS entregues,
                    SUM(CASE WHEN status = 'Cancelado' THEN 1 ELSE 0 END) AS cancelados,
                    COALESCE(SUM(CASE WHEN status != 'Cancelado'
                        THEN total ELSE 0 END), 0) AS valor
                FROM pedidos
            `),
            consultar(`
                SELECT
                    COALESCE(SUM(estoque), 0) AS unidades,
                    SUM(CASE WHEN estoque <= 0 THEN 1 ELSE 0 END) AS esgotados
                FROM produtos
            `)
        ]);

        const recentes = await consultarTodos(`
            SELECT id, nome_cliente, total, status, criado_em
            FROM pedidos
            ORDER BY id DESC
            LIMIT 5
        `);

        res.render('admin/index-admin', {
            indicadores: {
                produtos: produtos.total,
                categorias: categorias.total,
                marcas: marcas.total,
                clientes: clientes.total,
                pedidos: pedidos.total,
                recebidos: pedidos.recebidos || 0,
                preparacao: pedidos.preparacao || 0,
                enviados: pedidos.enviados || 0,
                entregues: pedidos.entregues || 0,
                cancelados: pedidos.cancelados || 0,
                valor: Number(pedidos.valor || 0),
                unidades: estoques.unidades || 0,
                esgotados: estoques.esgotados || 0
            },
            recentes
        });
    } catch (erro) {
        console.error('Erro no dashboard:', erro);
        res.status(500).send('Erro ao carregar indicadores administrativos.');
    }
});

app.get('/admin/pedidos', exigirAdmin, async (req, res) => {
    try {
        const pedidos = await consultarTodos(
            'SELECT * FROM pedidos ORDER BY id DESC'
        );

        for (const pedido of pedidos) {
            pedido.itens = await consultarTodos(
                'SELECT * FROM pedido_itens WHERE pedido_id = ? ORDER BY id',
                [pedido.id]
            );
        }

        const ativos = pedidos.filter(
            pedido => pedido.status !== 'Cancelado'
        );

        const estatisticas = {
            total: pedidos.length,
            recebidos: pedidos.filter(p => p.status === 'Recebido').length,
            preparacao: pedidos.filter(p => p.status === 'Em preparação').length,
            enviados: pedidos.filter(p => p.status === 'Enviado').length,
            entregues: pedidos.filter(p => p.status === 'Entregue').length,
            cancelados: pedidos.filter(p => p.status === 'Cancelado').length,
            valor: ativos.reduce(
                (soma, p) => soma + Number(p.total || 0),
                0
            )
        };

        res.render('admin/pedidos', {
            pedidos,
            estatisticas,
            aviso: String(req.query.aviso || ''),
            pedidoAviso: Number(req.query.pedido || 0)
        });
    } catch (erro) {
        res.status(500).send('Erro ao carregar pedidos.');
    }
});

app.post('/admin/pedidos/:id/status', exigirAdmin, async (req, res) => {
    const id = idValido(req.params.id);
    const novoStatus = String(req.body.status || '');

    const transicoes = {
        'Recebido': ['Em preparação', 'Cancelado'],
        'Em preparação': ['Enviado', 'Cancelado'],
        'Enviado': ['Entregue'],
        'Entregue': [],
        'Cancelado': []
    };

    if (!id || !Object.values(transicoes).flat().includes(novoStatus)) {
        return res.status(400).send('Pedido ou status inválido.');
    }

    try {
        const resultado = await enfileirarOperacao(async () => {
            await executar('BEGIN IMMEDIATE TRANSACTION');

            try {
                const pedido = await consultar(
                    'SELECT * FROM pedidos WHERE id = ?',
                    [id]
                );

                if (!pedido) throw new Error('Pedido não encontrado.');

                const permitidos = transicoes[pedido.status] || [];

                if (!permitidos.includes(novoStatus)) {
                    throw new Error('Transição de status não permitida.');
                }

                if (novoStatus === 'Cancelado') {
                    const itens = await consultarTodos(
                        `SELECT produto_id,
                                SUM(quantidade) AS quantidade
                         FROM pedido_itens
                         WHERE pedido_id = ?
                         GROUP BY produto_id`,
                        [id]
                    );

                    for (const item of itens) {
                        if (!item.produto_id) continue;

                        await executar(
                            `UPDATE produtos
                             SET estoque = estoque + ?
                             WHERE id = ?`,
                            [item.quantidade, item.produto_id]
                        );
                    }
                }

                const atualizacao = await executar(
                    `UPDATE pedidos
                     SET status = ?
                     WHERE id = ? AND status = ?`,
                    [novoStatus, id, pedido.status]
                );

                if (atualizacao.alteracoes !== 1) {
                    throw new Error('O pedido foi alterado. Atualize a página.');
                }

                await executar('COMMIT');

                return novoStatus === 'Cancelado'
                    ? 'cancelado'
                    : 'atualizado';
            } catch (erro) {
                await executar('ROLLBACK');
                throw erro;
            }
        });

        res.redirect(
            `/admin/pedidos?aviso=${resultado}&pedido=${id}`
        );
    } catch (erro) {
        res.status(400).send(
            `Não foi possível alterar o pedido: ${erro.message}`
        );
    }
});

app.use('/favoritos', require('./rotas/favoritos'));

app.use('/admin', exigirAdmin, appAdmin);

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
